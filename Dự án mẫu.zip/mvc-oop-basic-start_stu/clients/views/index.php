<div class="container">
    <div class="row">
        <h1 class="mb-5">Trang chủ</h1>
    </div>
</div>