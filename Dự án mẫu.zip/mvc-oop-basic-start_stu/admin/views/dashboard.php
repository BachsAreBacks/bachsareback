<div class="container">
    <div class="row">
        <h1>Trang Tổng Quan</h1>
    </div>
</div>